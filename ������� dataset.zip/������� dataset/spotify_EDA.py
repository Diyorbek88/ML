import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("dataset.csv")

# 1. Общая информация
print("Общая информация о датасете:")
print(df.info())
print("\n Описательная статистика:")
print(df.describe())

# 2. Распределение целевой переменной (popularity)
plt.figure(figsize=(8, 5))
sns.histplot(df['popularity'], bins=30, kde=True)
plt.title("Распределение популярности треков")
plt.xlabel("Популярность")
plt.ylabel("Количество треков")
plt.show()
# Вывод: видно, что большинство треков имеют популярность от 20 до 60, у почти 20000 песен популярность в районе 0

# 3. Boxplot по длительности
df['duration_min'] = df['duration_ms'] / 60000

plt.figure(figsize=(8, 5))
sns.boxplot(x=df['duration_min'])
plt.xlim(0, df['duration_min'].quantile(0.99))
plt.title("Распределение длительности треков (в минутах)")
plt.xlabel("Длительность трека (мин)")
plt.show()

# Вывод: есть выбросы среди очень длинных треков — возможно, аудиокниги или live-записи.

# 4. Тепловая карта корреляций
plt.figure(figsize=(14, 10))
corr_matrix = df.corr(numeric_only=True)
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Корреляционная матрица")
plt.show()
# Вывод: важные положительные корреляции с популярностью — loudness, danceability, energy.
# Отрицательные — instrumentalness, acousticness.

# 5. Вывод топ-10 признаков по корреляции с популярностью
target_corr = corr_matrix['popularity'].sort_values(ascending=False)
print("Топ признаков по корреляции с популярностью:\n", target_corr.head(10))

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

from sklearn.linear_model import Ridge
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import cross_val_score

df = pd.read_csv("dataset.csv")

# Feature Engineering
df['duration_minutes'] = df['duration_ms'] / 60000
df['is_short_song'] = (df['duration_minutes'] < 2.5).astype(int)
df['energy_danceability'] = df['energy'] * df['danceability']
df['acoustic_instrumental'] = df['acousticness'] * df['instrumentalness']
df.drop(['duration_ms'], axis=1, inplace=True)

# Корреляции
corrs = df.select_dtypes(include=[np.number]).corr()['popularity'].sort_values(ascending=False)
print("Корреляции признаков с популярностью:")
print(corrs)

# Признаки и таргет
X = df.drop('popularity', axis=1)
y = df['popularity']

# Оставим только числовые признаки
X = X.select_dtypes(include=[np.number])

# Обучение дерева решений
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
tree = DecisionTreeRegressor(random_state=42)
tree.fit(X_train, y_train)

# Важность признаков
importances = pd.Series(tree.feature_importances_, index=X.columns)
importances.sort_values().plot(kind='barh', figsize=(10, 6), title="Важность признаков")
plt.tight_layout()
plt.show()

# RMSE
print("RMSE дерева решений:", np.sqrt(mean_squared_error(y_test, tree.predict(X_test))))


models = {
    "Ridge Regression": Ridge(),
    "Decision Tree": DecisionTreeRegressor(random_state=42),
    "Gradient Boosting": GradientBoostingRegressor(random_state=42),
    "Neural Network (MLP)": MLPRegressor(max_iter=500, random_state=42)
}

best_model = None
best_score = float('inf')

print("Результаты кросс-валидации (5 фолдов, RMSE):")
for name, model in models.items():
    neg_rmse_scores = cross_val_score(model, X, y, cv=5, scoring='neg_root_mean_squared_error')
    rmse_scores = -neg_rmse_scores  # преобразуем обратно в положительное RMSE
    mean_rmse = rmse_scores.mean()
    std_rmse = rmse_scores.std()
    print(f"{name:25s}: {mean_rmse:.4f} ± {std_rmse:.4f}")

    if mean_rmse < best_score:  # ищем наименьший RMSE
        best_score = mean_rmse
        best_model = name

print("\n Лучшая модель по RMSE на кросс-валидации:")
print(f"{best_model} с RMSE = {best_score:.4f}")

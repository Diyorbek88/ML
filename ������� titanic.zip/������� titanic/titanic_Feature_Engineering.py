import pandas as pd
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import cross_val_score

df = pd.read_csv("titanic.csv")

# Заполнение пропусков
df['Age'] = df['Age'].fillna(df['Age'].median())
df['Fare'] = df['Fare'].fillna(df['Fare'].median())
df['Embarked'] = df['Embarked'].fillna(df['Embarked'].mode()[0])

# Удалим Cabin (слишком много пропусков) и Ticket (неинформативный)
df.drop(['Cabin', 'Ticket', 'Name', 'PassengerId'], axis=1, inplace=True)

# Создание нового признака - семья (есть ли родственники на борту)
df['FamilySize'] = df['SibSp'] + df['Parch']
df['IsAlone'] = (df['FamilySize'] == 0).astype(int)

# Преобразование категориальных признаков
df = pd.get_dummies(df, columns=['Sex', 'Embarked'], drop_first=True)

# Корреляции новых признаков с таргетом
corr_new = df.corr()['Survived'].sort_values(ascending=False)
print("Корреляции с таргетом:")
print(corr_new)

# Визуализация важности признаков с помощью дерева решений
X = df.drop('Survived', axis=1)
y = df['Survived']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

tree = DecisionTreeClassifier(random_state=42)
tree.fit(X_train, y_train)

importances = pd.Series(tree.feature_importances_, index=X.columns)
importances.sort_values().plot(kind='barh', figsize=(8,6), title="Важность признаков")
plt.show()

print("Accuracy дерева решений:", accuracy_score(y_test, tree.predict(X_test)))


models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42),
    "Neural Network (MLP)": MLPClassifier(max_iter=500, random_state=42)
}

best_model = None
best_score = 0.0

print("Результаты кросс-валидации (5 фолдов):")
for name, model in models.items():
    scores = cross_val_score(model, X, y, cv=5, scoring='accuracy')
    mean_score = scores.mean()
    std_score = scores.std()
    print(f"{name:25s}: {mean_score:.4f} ± {std_score:.4f}")
    if mean_score > best_score:
        best_score = mean_score
        best_model = name

print("\nЛучшая модель по точности на кросс-валидации:")
print(f"{best_model} с точностью {best_score:.4f}")



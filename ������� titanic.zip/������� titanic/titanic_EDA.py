import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("titanic.csv")

# Общая информация
print("Размер данных:", df.shape)
print("\n Первые строки:")
print(df.head())
print("\n Пропущенные значения:")
print(df.isnull().sum())

# Целевой признак
sns.countplot(data=df, x="Survived")
plt.title("Распределение по выживанию")
plt.xlabel("Выжил (1) / Не выжил (0)")
plt.ylabel("Количество пассажиров")
plt.show()
print("Видно, что погибших больше, чем выживших.")

# Распределение по полу и выживанию
sns.countplot(data=df, x="Sex", hue="Survived")
plt.title("Выживаемость по полу")
plt.show()
print("Женщины выживали значительно чаще, чем мужчины.")

# Выживаемость по классу
sns.countplot(data=df, x="Pclass", hue="Survived")
plt.title("Выживаемость по классу обслуживания")
plt.show()
print("Пассажиры 1 класса выживали чаще.")

# Возраст и выживание
plt.figure(figsize=(10,6))
sns.histplot(data=df, x="Age", hue="Survived", bins=30, kde=True)
plt.title("Распределение возраста по выживанию")
plt.show()
print("Маленькие дети и молодые взрослые имели больше шансов выжить.")

# Корреляции
corr = df[['Survived', 'Pclass', 'Age', 'SibSp', 'Parch', 'Fare']].corr()
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.title("Корреляционная матрица")
plt.show()



